/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx512.h"
#include "../common/t1fuv_4.c"
