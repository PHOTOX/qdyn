# compile fftw library
version=fftw-3.3.10

# check version
if [ $version != "fftw-3.3.10" ] && [ $version != "fftw-3.3.6" ]; then
    echo "Error: version must be fftw-3.3.10 or fftw-3.3.6"
    exit
fi

# get the current directory
pwd=$(pwd)

# enter the source code directory
cd $version-source_code

# clean previous compilation
make distclean

# configure, prefix is the installation directory where the library will be installed (change the path if needed)
./configure --prefix=$pwd/$version

# compile
make
make install

# final comment
echo -e "\nNow put the following line in the Makefile in src:"
echo "LIBS = -L$pwd/$version/lib -lfftw3 -lm -llapack"
