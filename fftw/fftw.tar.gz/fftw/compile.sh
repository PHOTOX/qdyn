# compile fftw library
version=fftw-3.3.10

# complide to current folder
pwd=$(pwd)
cd $version-source_code

# clean previous compilation
make distclean

# configure
#./configure --prefix=/home/janos/Programs/fftw/fftw-3.3.6
./configure --prefix=$pwd/$version

# compile
make
make install

# final comment
echo -e "\nNow put the following line in the Makefile in src:"
echo "LIBS = -L$pwd/$version/lib -lfftw3 -lm -llapack"
